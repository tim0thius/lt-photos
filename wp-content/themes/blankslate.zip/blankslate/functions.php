<?php
	# blankslate init
	require_once('functions/blankslate.php');

	# helpers
	require_once('functions/helpers.php');

	# scripts
	require_once('functions/scripts.php');

	# post types
	require_once('functions/types/gallery.php');